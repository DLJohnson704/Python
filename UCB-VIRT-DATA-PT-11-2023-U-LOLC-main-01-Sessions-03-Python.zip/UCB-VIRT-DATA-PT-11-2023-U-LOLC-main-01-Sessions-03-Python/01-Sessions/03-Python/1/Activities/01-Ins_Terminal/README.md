Instructor demo

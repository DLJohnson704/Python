# Take input of you and your neighbor

# Take how long each of you have been coding

# Add total month

# Print results

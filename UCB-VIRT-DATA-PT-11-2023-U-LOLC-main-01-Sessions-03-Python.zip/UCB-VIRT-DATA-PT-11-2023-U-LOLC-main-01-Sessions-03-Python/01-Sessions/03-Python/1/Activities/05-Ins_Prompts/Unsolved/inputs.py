# Collects the user's input for the prompt "What is your name?"


# Collects the user's input for the prompt "How old are you?" and converts the string to an integer.


# Collects the user's input for the prompt "Is input truthy?" and converts it to a boolean. Note that non-zero,
#   non-empty objects are truth-y.

# Creates three print statements that to respond with the output.

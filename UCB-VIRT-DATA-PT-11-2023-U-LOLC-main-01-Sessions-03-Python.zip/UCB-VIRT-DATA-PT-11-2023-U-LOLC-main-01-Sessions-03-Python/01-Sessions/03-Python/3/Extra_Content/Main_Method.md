# Main Method Model

* When running a python file as a script, we utilize `if __name__ == "__main__":`.

* Add more here

* Reference this link for more information: [Main Method Model](https://docs.python.org/3/library/__main__.html)
